module.exports = require('./src/polyline.js');
