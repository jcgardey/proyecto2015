## 0.2.0

* Add `.toGeoJSON` method to convert an encoded polyline to GeoJSON
  LineString.

## 0.1.0

* Add `.fromGeoJSON` method to encode GeoJSON geometries as polylines
  without needing to manually flip coordinates.
